# UX Portfolio

This repository contains the code for a UX portfolio website with a clean layout and functional navigation bar.

## 📁 ZIP File Contents

- **index.html** – The main HTML page of the portfolio. It includes all sections (Home, About Me, Projects, Contact) in a single page layout, using semantic tags for structure and a functional navigation bar.
- **style.css** – An external CSS stylesheet that styles the portfolio. This is extracted from any inline styles in the original layout for cleaner, more maintainable code.
- **README.md** – A markdown file explaining the project, content, and instructions for usage (especially how to deploy on GitHub Pages).

By structuring it this way, you can easily edit content or styles separately, and the project is ready to be published by simply uploading these files to a repository.
